// Optional secure AI tutor backend for Study Fantasy.
// Requires Node.js 18+ and OPENAI_API_KEY set in your shell environment.
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const PORT = Number(process.env.PORT || 3000);
const ROOT = __dirname;
const API_KEY = process.env.OPENAI_API_KEY;
const MIME = {'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.json':'application/json; charset=utf-8'};
function send(res, status, body, type='application/json; charset=utf-8') { res.writeHead(status, {'Content-Type':type,'X-Content-Type-Options':'nosniff'}); res.end(typeof body === 'string' ? body : JSON.stringify(body)); }
const server = http.createServer(async (req,res) => {
  if (req.method === 'POST' && req.url === '/api/tutor') {
    if (!API_KEY) return send(res, 503, {error:'Set OPENAI_API_KEY before using live AI.'});
    let raw=''; req.on('data', chunk => { raw += chunk; if (raw.length > 20000) req.destroy(); });
    req.on('end', async () => {
      try {
        const input = JSON.parse(raw || '{}');
        const topic = String(input.topic || 'Study topic').slice(0,160);
        const lesson = String(input.lesson || '').slice(0,5000);
        const facts = Array.isArray(input.facts) ? input.facts.slice(0,8).map(x=>String(x).slice(0,500)) : [];
        const ai = await fetch('https://api.openai.com/v1/responses', {method:'POST',headers:{'Authorization':`Bearer ${API_KEY}`,'Content-Type':'application/json'},body:JSON.stringify({model:process.env.OPENAI_MODEL || 'gpt-4.1-mini',input:[{role:'system',content:[{type:'input_text',text:'You are a friendly study tutor. Teach in a short, accurate, beginner-friendly mini lesson. Explain the core idea, give one concrete example, and end with one quick recall prompt. Do not claim the provided lesson says things it does not.'}]},{role:'user',content:[{type:'input_text',text:`Topic: ${topic}\nExisting lesson: ${lesson}\nKey facts: ${facts.join('; ')}\nTeach me a little before I start studying.`}]}]})});
        const data = await ai.json();
        if (!ai.ok) return send(res, 502, {error:data.error?.message || 'AI provider request failed.'});
        const explanation = (data.output || []).flatMap(x=>x.content || []).filter(x=>x.type==='output_text').map(x=>x.text).join('\n').trim();
        return send(res, 200, {explanation: explanation || 'I could not generate a lesson just now. Please try again.'});
      } catch (e) { return send(res, 400, {error:'Could not process the tutor request.'}); }
    });
    return;
  }
  const pathname = decodeURIComponent((req.url || '/').split('?')[0]);
  const target = path.resolve(ROOT, '.' + (pathname === '/' ? '/index.html' : pathname));
  if (!target.startsWith(ROOT + path.sep) && target !== path.join(ROOT,'index.html')) return send(res, 403, {error:'Forbidden'});
  fs.readFile(target, (err, data) => { if (err) return send(res,404,{error:'Not found'}); send(res,200,data,MIME[path.extname(target)] || 'application/octet-stream'); });
});
server.listen(PORT, () => console.log(`Study Fantasy running at http://localhost:${PORT}`));
