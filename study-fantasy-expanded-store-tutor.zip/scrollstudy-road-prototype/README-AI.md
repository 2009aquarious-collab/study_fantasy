# Study Fantasy — local AI tutor setup

The browser app includes a short built-in warm-up lesson before the map. For a real generative AI explanation, run this included server so the API key stays on the server rather than inside `index.html`.

## Start on macOS

1. Install Node.js 18 or newer.
2. Open Terminal and `cd` into this folder.
3. Set your API key in that Terminal session: `export OPENAI_API_KEY="your_api_key_here"`
4. Optional model override: `export OPENAI_MODEL="gpt-4.1-mini"`
5. Run `npm start`.
6. Open `http://localhost:3000` (do not open `index.html` directly if you want live AI).

The app still teaches from its built-in content when the API server/key is not configured. Never paste your API key into the HTML or share it publicly.
