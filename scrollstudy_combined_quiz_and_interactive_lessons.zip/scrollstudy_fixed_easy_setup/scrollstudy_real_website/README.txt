SCROLLSTUDY — DEPLOYABLE ONLINE WEBSITE STARTER

This is a static website with Supabase email/password authentication and cloud-saved per-user study state. You must connect your own Supabase project before it works online. It is not published yet.

A. Create the backend (free tier may be available)
1. Go to https://supabase.com/ and create a project.
2. In Project Settings / API, copy the Project URL and the anon/public key. Never put a service_role key in a browser website.
3. Open SQL Editor in Supabase, create a new query, paste all of supabase_schema.sql, and run it.
4. In Authentication settings, configure the site URL after you publish. For initial testing, email confirmation may be enabled; that means users must click the verification link before logging in.

B. Connect the website
1. Open index.html in a text editor.
2. Near the top of the JavaScript, find:
   const SUPABASE_URL = "PASTE_YOUR_SUPABASE_PROJECT_URL_HERE";
   const SUPABASE_ANON_KEY = "PASTE_YOUR_SUPABASE_ANON_PUBLIC_KEY_HERE";
3. Replace the quoted placeholders with your Project URL and anon/public key.
4. Save the file.

C. Publish without GitHub
1. Go to https://app.netlify.com/drop and sign in / create an account.
2. Drag the extracted scrollstudy_real_website folder onto the page (index.html should be directly inside it).
3. Netlify will give you a public website URL.
4. In Supabase Authentication URL Configuration, set Site URL to that Netlify URL. Add the URL to Redirect URLs if needed.
5. Open the URL and create an account with your email.

Included features
- Email signup/login through Supabase Auth
- Per-user cloud-saved likes, saves, subscriptions, and uploaded-note lessons
- TikTok-inspired lesson feed, sample channels, and quiz cards
- Export personal study data backup

Current limitations
- This is a deployable starter, not a website already published by me; I cannot create your hosting/backend accounts or enter your private credentials.
- The lesson cards are video-style visuals, not real generated video clips. No AI API is connected.
- Sharing is via device share sheet or copied summary, not a public social feed. The channels are fictional.
- Uploaded notes are processed in the browser; the generated lessons are stored as a JSON state row in Supabase.
- For a production launch, add stronger validation, rate limits, privacy policy, terms, abuse reporting, and test RLS/auth settings. Never expose Supabase service_role keys in client code.


UPDATED LESSON ACCESS FIX
This version makes lesson previews clickable to open the full lesson and makes channel cards open their lessons.
Use setup.html to configure Supabase: choose this folder's index.html, enter the Project URL and publishable/anon key, and download the configured index.html. Replace this folder's index.html with the downloaded one before publishing.


COMBINED UPDATE
This package combines the quiz reliability update and guided interactive lesson experience. The index.html includes both sets of changes. It is still a starter app: AI-generated video and narration are not connected.
